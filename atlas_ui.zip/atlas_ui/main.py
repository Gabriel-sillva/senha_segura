import os
import sys

from PySide6.QtCore import Qt, QSize, QThread, Signal
from PySide6.QtGui import QPixmap, QIcon, QFontDatabase, QFont, QGuiApplication
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton,
    QHBoxLayout, QVBoxLayout, QFrame, QScrollArea, QSizePolicy,
    QMessageBox
)

import scanner

# =========================================================
# PATHS / ASSETS (ordem certa)
# =========================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def asset_path(*parts) -> str:
    return os.path.join(BASE_DIR, "assets", *parts)

# imagens
ASSET_LOGO_ATLAS   = asset_path("img", "logo_atlas.png")
ASSET_BOSCH_LIGHT  = asset_path("img", "logo_bosch_light.png")
ASSET_BOSCH_DARK   = asset_path("img", "logo_bosch_dark.png")
ASSET_SUPERGRAPHIC = asset_path("img", "Supergraphic.png")

# icons
ASSET_ICON_LIGHT_ON  = asset_path("icons", "light-on.png")
ASSET_ICON_LIGHT_OFF = asset_path("icons", "light-off.png")

# fonts
FONT_REGULAR = asset_path("fonts", "BoschSans-Regular-v5_003.ttf")
FONT_BOLD    = asset_path("fonts", "BoschPixmap(img_path)FONT_BOLD    = asset_path("fonts", "BoschSans-Bold-v5_003.ttf"))
        self._h = fixed_h

        self.setFixedHeight(self._h)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setAlignment(Qt.AlignCenter)

        if self._pix.isNull():
            print("⚠️ Supergraphic não carregou:", img_path)

        self._apply_scaled()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._apply_scaled()

    def _apply_scaled(self):
        if self._pix.isNull():
            return
        w = max(1, self.width())
        scaled = self._pix.scaled(w, self._h, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        self.setPixmap(scaled)


# =========================================================
# WORKER THREAD (pra UI não travar)
# =========================================================
class ScanWorker(QThread):
    finished = Signal(dict, list, bool)  # identidade, relatorio, api_online
    error = Signal(str)

    def run(self):
        try:
            identidade, relatorio, api_online = scanner.gerar_relatorio_final()
            self.finished.emit(identidade, relatorio, api_online)
        except Exception as e:
            self.error.emit(str(e))


# =========================================================
# CARD (software item) - sem setinha extra, só DIAGNÓSTICO
# =========================================================
class SoftwareCard(QFrame):
    def __init__(self, nome: str, v_inst: str, v_esp: str, status: str, detalhes: str):
        super().__init__()
        self.setObjectName("SoftwareCard")
        self._open = False
        self.detalhes = detalhes or "Sem diagnóstico."

        # Mapeia status
        if status == "Atualizado":
            status_text = "✓ CONFORME"
            kind = "ok"
        elif status == "Desatualizado":
            status_text = "⚠ ATUALIZAR"
            kind = "warn"
        else:
            status_text = "✕ PENDENTE"
            kind = "err"

        # Widgets
        lbl_title = QLabel(nome.upper())
        lbl_title.setObjectName("CardTitle")

        lbl_sub = QLabel(f"Inst. {v_inst} | Esp. {v_esp}")
        lbl_sub.setObjectName("CardSub")

        lbl_status = QLabel(status_text)
        lbl_status.setObjectName(f"StatusLabel_{kind}")

        self.btn_diag = QPushButton("DIAGNÓSTICO ▾")
        self.btn_diag.setObjectName("DiagButton")
        self.btn_diag.clicked.connect(self.toggle_details)

        # Header
        left = QVBoxLayout()
        left.setSpacing(2)
        left.addWidget(lbl_title)
        left.addWidget(lbl_sub)

        right = QHBoxLayout()
        right.setSpacing(10)
        right.addWidget(lbl_status, 0, Qt.AlignRight)

        header = QHBoxLayout()
        header.addLayout(left, 1)
        header.addLayout(right, 0)

        # Details box
        self.details_box = QFrame()
        self.details_box.setObjectName("DetailsBox")
        dlay = QVBoxLayout(self.details_box)
        dlay.setContentsMargins(10, 8, 10, 8)

        lbl_details = QLabel(self.detalhes)
        lbl_details.setObjectName("DetailsText")
        lbl_details.setWordWrap(True)
        dlay.addWidget(lbl_details)

        self.details_box.hide()

        # Footer
        footer = QHBoxLayout()
        footer.addStretch(1)
        footer.addWidget(self.btn_diag)

        # Main
        main = QVBoxLayout(self)
        main.setContentsMargins(14, 12, 14, 12)
        main.setSpacing(10)
        main.addLayout(header)
        main.addLayout(footer)
        main.addWidget(self.details_box)

        # Se estiver conforme, esconde diagnóstico
        if status == "Atualizado":
            self.btn_diag.hide()

    def toggle_details(self):
        self._open = not self._open
        self.details_box.setVisible(self._open)
        self.btn_diag.setText("DIAGNÓSTICO ▴" if self._open else "DIAGNÓSTICO ▾")


# =========================================================
# MAIN WINDOW
# =========================================================
class MainWindow(QMainWindow):
    def __init__(self, font_family: str | None = None):
        super().__init__()
        self.setWindowTitle("ATLAS")
        self.resize(720, 860)

        self.font_family = font_family
        self.is_dark = False

        self.last_identidade = None
        self.last_relatorio = None
        self.last_api_online = None
        self.worker = None

        # Root
        root = QWidget()
        root.setObjectName("Root")
        self.setCentralWidget(root)

        layout = QVBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ---------------- TOPBAR
        top = QFrame()
        top.setObjectName("TopBar")
        top_lay = QHBoxLayout(top)
        top_lay.setContentsMargins(16, 10, 16, 10)
        top_lay.setSpacing(12)

        self.lbl_bosch = QLabel()
        self.lbl_bosch.setObjectName("LogoBosch")
        self.lbl_bosch.setPixmap(pixmap_height(ASSET_BOSCH_LIGHT, 28))

        self.lbl_atlas = QLabel()
        self.lbl_atlas.setObjectName("LogoAtlas")
        self.lbl_atlas.setAlignment(Qt.AlignCenter)
        self.lbl_atlas.setPixmap(pixmap_height(ASSET_LOGO_ATLAS, 34))

        self.btn_theme = QPushButton()
        self.btn_theme.setObjectName("TopButton")
        self.btn_theme.setFixedSize(36, 32)
        self.btn_theme.setIcon(QIcon(ASSET_ICON_LIGHT_OFF))  # começa claro -> sugere escuro
        self.btn_theme.setIconSize(QSize(18, 18))
        self.btn_theme.clicked.connect(self.toggle_theme)

        self.btn_close = QPushButton("✕")
        self.btn_close.setObjectName("TopClose")
        self.btn_close.setFixedSize(36, 32)
        self.btn_close.clicked.connect(self.close)

        top_lay.addWidget(self.lbl_bosch, 0, Qt.AlignLeft)
        top_lay.addWidget(self.lbl_atlas, 1)
        top_lay.addWidget(self.btn_theme, 0, Qt.AlignRight)
        top_lay.addWidget(self.btn_close, 0, Qt.AlignRight)

        # ---------------- HEADER
        header = QFrame()
        header.setObjectName("Header")
        h_lay = QVBoxLayout(header)
        h_lay.setContentsMargins(0, 18, 0, 10)
        h_lay.setSpacing(10)

        self.lbl_machine = QLabel("MÁQUINA: -")
        self.lbl_machine.setObjectName("MachineLabel")
        self.lbl_machine.setAlignment(Qt.AlignCenter)

        legend = QHBoxLayout()
        legend.setSpacing(28)
        legend.setAlignment(Qt.AlignCenter)
        legend.addLayout(self.make_status("ok", "OK"))
        legend.addLayout(self.make_status("warn", "ATUALIZAR"))
        legend.addLayout(self.make_status("err", "ERRO"))

        h_lay.addWidget(self.lbl_machine)
        h_lay.addLayout(legend)

        # ---------------- CONTENT (Painel + Supergraphic fixo + Scroll)
        content = QFrame()
        content.setObjectName("ContentFrame")
        c_lay = QVBoxLayout(content)
        c_lay.setContentsMargins(26, 14, 26, 14)
        c_lay.setSpacing(0)

        panel = QFrame()
        panel.setObjectName("SoftPanel")
        panel_lay = QVBoxLayout(panel)
        panel_lay.setContentsMargins(14, 14, 14, 14)
        panel_lay.setSpacing(10)

        # Supergraphic FIXO no topo do painel (igual Figma)
        self.supergraphic = SupergraphicBanner(ASSET_SUPERGRAPHIC, fixed_h=14)
        panel_lay.addWidget(self.supergraphic)

        # Scroll para cards
        self.scroll = QScrollArea()
        self.scroll.setObjectName("ScrollArea")
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)

        self.scroll_widget = QWidget()
        self.scroll_widget.setObjectName("ScrollWidget")

        self.cards_lay = QVBoxLayout(self.scroll_widget)
        self.cards_lay.setContentsMargins(0, 0, 0, 0)
        self.cards_lay.setSpacing(12)

        self.placeholder = QLabel("Clique em 'Iniciar Varredura' para listar os softwares.")
        self.placeholder.setObjectName("Placeholder")
        self.placeholder.setAlignment(Qt.AlignCenter)
        self.cards_lay.addWidget(self.placeholder)

        self.spacer = QWidget()
        self.spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.cards_lay.addWidget(self.spacer)

        self.scroll.setWidget(self.scroll_widget)
        panel_lay.addWidget(self.scroll, 1)

        c_lay.addWidget(panel, 1)

        # ---------------- BOTTOM
        bottom = QFrame()
        bottom.setObjectName("BottomBar")
        b_lay = QHBoxLayout(bottom)
        b_lay.setContentsMargins(60, 18, 60, 26)
        b_lay.setSpacing(28)
        b_lay.setAlignment(Qt.AlignCenter)

        self.btn_copy = QPushButton("Copiar log")
        self.btn_copy.setObjectName("BtnOutline")
        self.btn_copy.clicked.connect(self.copy_log)

        self.btn_scan = QPushButton("Iniciar Varredura")
        self.btn_scan.setObjectName("BtnPrimary")
        self.btn_scan.clicked.connect(self.start_scan)

        b_lay.addWidget(self.btn_copy)
        b_lay.addWidget(self.btn_scan)

        # MOUNT TUDO (isso tava faltando no teu)
        layout.addWidget(top)
        layout.addWidget(header)
        layout.addWidget(content, 1)
        layout.addWidget(bottom)

        # Tema inicial
        self.apply_light_theme()

    def make_status(self, kind: str, text: str):
        row = QHBoxLayout()
        row.setSpacing(8)
        dot = QLabel("●")
        dot.setObjectName(f"Dot_{kind}")
        lbl = QLabel(text)
        lbl.setObjectName("StatusText")
        row.addWidget(dot)
        row.addWidget(lbl)
        return row

    # ---------------- THEMES (QSS externo)
    def apply_light_theme(self):
        qss = load_qss(QSS_LIGHT)
        if self.font_family:
            qss = f'*{{font-family:"{self.font_family}";}}' + qss
        self.setStyleSheet(qss)
        self.lbl_bosch.setPixmap(pixmap_height(ASSET_BOSCH_LIGHT, 28))

    def apply_dark_theme(self):
        qss = load_qss(QSS_DARK)
        if self.font_family:
            qss = f'*{{font-family:"{self.font_family}";}}' + qss
        self.setStyleSheet(qss)
        self.lbl_bosch.setPixmap(pixmap_height(ASSET_BOSCH_DARK, 28))

    def toggle_theme(self):
        self.is_dark = not self.is_dark
        if self.is_dark:
            self.apply_dark_theme()
            self.btn_theme.setIcon(QIcon(ASSET_ICON_LIGHT_ON))   # escuro -> sugere claro
        else:
            self.apply_light_theme()
            self.btn_theme.setIcon(QIcon(ASSET_ICON_LIGHT_OFF))  # claro -> sugere escuro

    # ---------------- CARDS
    def clear_cards(self):
        while self.cards_lay.count():
            item = self.cards_lay.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        self.spacer = QWidget()
        self.spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.cards_lay.addWidget(self.spacer)

    # ---------------- SCAN FLOW
    def start_scan(self):
        self.btn_scan.setEnabled(False)
        self.btn_copy.setEnabled(False)
        self.btn_scan.setText("Varredura...")

        self.clear_cards()
        loading = QLabel("Executando varredura... aguarde.")
        loading.setObjectName("Placeholder")
        loading.setAlignment(Qt.AlignCenter)
        self.cards_lay.insertWidget(0, loading)

        self.worker = ScanWorker()
        self.worker.finished.connect(self.on_finished)
        self.worker.error.connect(self.on_error)
        self.worker.start()

    def on_finished(self, identidade: dict, relatorio: list, api_online: bool):
        self.last_identidade = identidade
        self.last_relatorio = relatorio
        self.last_api_online = api_online

        self.lbl_machine.setText(f"MÁQUINA: {identidade.get('hostname', '-')}")
        self.render_cards(relatorio)

        self.btn_scan.setEnabled(True)
        self.btn_copy.setEnabled(True)
        self.btn_scan.setText("Iniciar Varredura")

    def on_error(self, msg: str):
        QMessageBox.critical(self, "Erro", f"Falha na varredura:\n{msg}")
        self.btn_scan.setEnabled(True)
        self.btn_copy.setEnabled(True)
        self.btn_scan.setText("Iniciar Varredura")

    def render_cards(self, relatorio: list):
        self.clear_cards()

        if not relatorio:
            empty = QLabel("Nenhum software retornado.")
            empty.setObjectName("Placeholder")
            empty.setAlignment(Qt.AlignCenter)
            self.cards_lay.insertWidget(0, empty)
            return

        insert_at = 0
        for item in relatorio:
            card = SoftwareCard(
                nome=item.get("nome", "N/A"),
                v_inst=item.get("versao_instalada", "N/A"),
                v_esp=item.get("versao_esperada", "N/A"),
                status=item.get("status", "N/A"),
                detalhes=item.get("detalhes", "")
            )
            self.cards_lay.insertWidget(insert_at, card)
            insert_at += 1

    def copy_log(self):
        if not self.last_identidade or not self.last_relatorio:
            QMessageBox.information(self, "Info", "Execute a varredura antes para gerar o log.")
            return

        text = scanner.copiar_log_teams(self.last_identidade, self.last_relatorio)
        QGuiApplication.clipboard().setText(text)
        QMessageBox.information(self, "Copiado", "Log copiado para a área de transferência.")


# =========================================================
# ENTRYPOINT
# =========================================================
def main():
    app = QApplication(sys.argv)

    families = load_bosch_fonts()
    font_family = families[0] if families else None

    if font_family:
        app.setFont(QFont(font_family, 12))

    window = MainWindow(font_family=font_family)
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()

# qss
QSS_LIGHT = asset_path("style_light.qss")
QSS_DARK  = asset_path("style_dark.qss")


# =========================================================
# UTILS
# =========================================================
def load_qss(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        print(f"⚠️ Não consegui ler QSS: {path} -> {e}")
        return ""

def load_bosch_fonts() -> list:
    fonts = [FONT_REGULAR, FONT_BOLD]
    families = []

    print("\n====== DEBUG FONTS ======")
    print("📌 BASE_DIR:", BASE_DIR)

    for f in fonts:
        print("🔎 Fonte:", f, "| exists:", os.path.exists(f))
        font_id = QFontDatabase.addApplicationFont(f)
        if font_id != -1:
            fams = QFontDatabase.applicationFontFamilies(font_id)
            families += fams
            print("✅ carregou:", fams)
        else:
            print("❌ addApplicationFont falhou:", f)

    # remove duplicados mantendo ordem
    seen = set()
    families = [x for x in families if not (x in seen or seen.add(x))]

    print("✅ Font families carregadas (final):", families)
    print("=========================\n")
    return families

def pixmap_height(path: str, h: int) => QPixmap:
    pix = QPixmap(path)
    if pix.isNull():
        print("⚠️ Não carregou imagem:", path)
        return QPixmap()
    return pix.scaledToHeight(h, Qt.SmoothTransformation)


# =========================================================
# SUPERGRAPHIC (fixo no topo do painel, responsivo)
# =========================================================
class SupergraphicBanner(QLabel):
    def __init__(self, img_path: str, fixed_h: int = 14):
        super().__init__()
        self.setObjectName("Supergraphic")
