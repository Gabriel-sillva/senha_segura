import os
import winreg
import ctypes
import socket
import requests
from datetime import datetime

# =================================================================
# CONFIGURAÇÕES E ENDPOINTS
# =================================================================
URL_API_SOFTWARES = "http://localhost:8000/softwares/"

# Lista utilizada caso a API esteja offline
BACKUP_LOCAL = [
    {"nome": "Google Chrome", "versao_esperada": "122.0", "caminho_padrao": r"C:\Program Files\Google\Chrome\Application\chrome.exe"},
    {"nome": "Python", "versao_esperada": "3.11.0", "caminho_padrao": r"C:\Windows\py.exe"},
    {"nome": "VS Code", "versao_esperada": "1.85.0", "caminho_padrao": r"%LocalAppData%\Programs\Microsoft VS Code\Code.exe"},
    {"nome": "Git", "versao_esperada": "2.43.0", "caminho_padrao": r"C:\Program Files\Git\bin\git.exe"},
    {"nome": "Microsoft Edge", "versao_esperada": "122.0", "caminho_padrao": r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"},
    {"nome": "Notepad++", "versao_esperada": "8.6.0", "caminho_padrao": r"C:\Program Files\Notepad++\notepad++.exe"},
]

# =================================================================
# NÚCLEO DE EXTRAÇÃO DE VERSÃO
# =================================================================
def obter_versao_binario(caminho):
    """Extrai a versão de um arquivo .exe usando a API de versão do Windows (ctypes)."""
    try:
        caminho_real = os.path.expandvars(caminho)
        if not os.path.exists(caminho_real): return None
        
        # Obtém o tamanho da estrutura de informação da versão
        size = ctypes.windll.version.GetFileVersionInfoSizeW(caminho_real, None)
        if size <= 0: return "Localizado"
        
        # Lê os dados da versão
        res = ctypes.create_string_buffer(size)
        ctypes.windll.version.GetFileVersionInfoW(caminho_real, None, size, res)
        handle = ctypes.c_void_p()
        vsize = ctypes.c_uint()
        
        # Consulta o valor da versão fixa
        ctypes.windll.version.VerQueryValueW(res, "\\", ctypes.byref(handle), ctypes.byref(vsize))
        info = ctypes.cast(handle, ctypes.POINTER(ctypes.c_ushort))
        
        # Retorna no formato standard: Major.Minor.Build.Revision
        return f"{info[1]}.{info[0]}.{info[3]}.{info[2]}"
    except:
        return "Localizado"

# =================================================================
# LÓGICA DE VERIFICAÇÃO (REGISTRO -> DISCO)
# =================================================================
def verificar_software(software):
    """
    Realiza a auditoria de um software específico.
    Passo 1: Procura no Registro do Windows (Painel de Controle).
    Passo 2: Procura o executável no caminho padrão configurado.
    """
    nome_alvo = str(software.get('nome_software', software.get('nome', ''))).lower().strip()
    caminho_bruto = software.get('caminho_padrao', software.get('caminho', ''))
    versao_esperada = str(software.get('versao_esperada', software.get('versao', '0.0')))
    
    if not nome_alvo: return None

    # --- PASSO 1: BUSCA NO REGISTRO DO WINDOWS ---
    raizes = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Uninstall")
    ]

    for root, path in raizes:
        try:
            with winreg.OpenKey(root, path) as key:
                for i in range(winreg.QueryInfoKey(key)[0]):
                    try:
                        sub_key_name = winreg.EnumKey(key, i)
                        with winreg.OpenKey(key, sub_key_name) as subkey:
                            display_name = str(winreg.QueryValueEx(subkey, "DisplayName")[0]).lower()
                            
                            # Validação flexível (Ex: VS Code vs Visual Studio Code)
                            if nome_alvo in display_name or ("vs code" in nome_alvo and "visual studio code" in display_name):
                                versao = str(winreg.QueryValueEx(subkey, "DisplayVersion")[0])
                                status = "Atualizado" if versao >= versao_esperada else "Desatualizado"
                                detalhes = "Software em conformidade no Registro." if status == "Atualizado" else f"Versão instalada ({versao}) é inferior à esperada ({versao_esperada})."
                                return status, versao, detalhes
                    except: continue
        except: continue

    # --- PASSO 2: BUSCA POR BINÁRIO NO DISCO (FALLBACK) ---
    caminho_alvo = os.path.expandvars(caminho_bruto)
    if caminho_alvo and os.path.exists(caminho_alvo):
        versao_disco = obter_versao_binario(caminho_alvo)
        if versao_disco and versao_disco != "Localizado":
            status = "Atualizado" if versao_disco >= versao_esperada else "Desatualizado"
            detalhes = "Executável encontrado no diretório de programas." if status == "Atualizado" else "Binário encontrado, mas está desatualizado."
            return status, versao_disco, detalhes
        return "Atualizado", "Localizado", "Software presente no disco, versão ilegível."

    # --- FALHA: SOFTWARE NÃO ENCONTRADO ---
    return "Não Instalado", "0.0", "Software não encontrado no Registro nem nos caminhos de instalação padrão."

# =================================================================
# GESTÃO DE DADOS E RELATÓRIO
# =================================================================
def obter_lista_softwares():
    """Tenta buscar a lista de auditoria na API, senão usa o backup local."""
    try:
        response = requests.get(URL_API_SOFTWARES, timeout=2) 
        if response.status_code == 200:
            return response.json(), True
    except:
        pass
    return BACKUP_LOCAL, False 

def gerar_relatorio_final():
    """Função principal consumida pela interface.py"""
    identidade = {
        "hostname": socket.gethostname(),
        "data": datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    }
    
    softwares_para_verificar, api_online = obter_lista_softwares()
    relatorio = []

    for soft in softwares_para_verificar:
        resultado = verificar_software(soft)
        if resultado:
            status, v_instalada, detalhes = resultado
            relatorio.append({
                "nome": soft.get('nome_software', soft.get('nome', 'N/A')),
                "status": status,
                "versao_instalada": v_instalada,
                "versao_esperada": soft.get('versao_esperada', soft.get('versao', '0.0')),
                "detalhes": detalhes 
            })
    
    return identidade, relatorio, api_online

def copiar_log_teams(identidade, resultados):
    """Gera uma string formatada para facilitar o envio via Microsoft Teams/E-mail."""
    linha = "=" * 45
    data_log = identidade.get('data') or datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    
    texto = f"{linha}\n📋 RELATÓRIO DE AUDITORIA - ATLAS\n"
    texto += f"🖥️ MÁQUINA: {identidade.get('hostname', 'Desconhecido')}\n"
    texto += f"📅 DATA: {data_log}\n{linha}\n\n"

    for res in resultados:
        emoji = "✅" if res['status'] == "Atualizado" else "❌"
        texto += f"{emoji} {res['nome'].upper()}\n"
        texto += f"   Status: {res['status']}\n"
        texto += f"   Versão: {res.get('versao_instalada', 'N/A')} (Esperada: {res.get('versao_esperada', 'N/A')})\n"
        
        if res['status'] != "Atualizado":
            diag = res.get('detalhes', 'Divergência detectada.')
            texto += f"   🔍 Diagnóstico: {diag}\n"
        texto += "\n"

    texto += f"{linha}\nGerado pelo Sistema ATLAS."
    return texto