from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Mudamos para SQLite para funcionar sem precisar do serviço Postgres ligado
DATABASE_URL = "sqlite:///./atlas.db"

# O 'connect_args' é necessário APENAS para o SQLite no FastAPI
engine = create_engine(
    DATABASE_URL, connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Função que a API vai usar para abrir/fechar o banco
def get_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()