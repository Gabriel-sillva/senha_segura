from database import engine
from models import table_registry # Vamos usar o registry que você tem no models.py
import models # Garante que as classes SoftwareModel e UserModel sejam lidas

def resetar_banco():
    print("🔄 Limpando e recriando o banco de dados...")
    try:
        # O table_registry é quem comanda as tabelas no seu projeto
        table_registry.metadata.drop_all(bind=engine)
        print("✅ Tabelas antigas removidas!")
        
        table_registry.metadata.create_all(bind=engine)
        print("✅ Tabelas novas criadas (com os nomes em português)!")
        
        print("\n🚀 Tudo pronto! Pode rodar 'python app.py'")
    except Exception as e:
        print(f"❌ Erro: {e}")

if __name__ == "__main__":
    resetar_banco()