from fastapi import APIRouter, Depends

from fastapi.exceptions import HTTPException

from fastapi.security import OAuth2PasswordRequestForm

from http import HTTPStatus

from schemas import SoftwareSchema, SoftwareDB, UserSchema, UserPublicSchema, Token

from sqlalchemy import select

from sqlalchemy.orm import Session

from sqlalchemy.exc import IntegrityError

from models import SoftwareModel, UserModel

from database import get_session

from security import hash_password, verify_password, create_access_token

router = APIRouter(prefix='/auth', tags=['auth'])

@router.post('/token/', response_model=Token)
def create_token(form_data: OAuth2PasswordRequestForm = Depends(), session : Session = Depends(get_session)):
    db_user = session.scalar(
        select(UserModel).where(UserModel.email == form_data.username)
    )

    if not db_user or not verify_password(form_data.password, db_user.password):
        raise HTTPException(status_code=HTTPStatus.UNAUTHORIZED, detail="Invalid username or password")
    
    
    to_encode = {'sub': db_user.email}

    token = create_access_token(to_encode)

    return {'access_token': token, 'token_type': 'Bearer'}

