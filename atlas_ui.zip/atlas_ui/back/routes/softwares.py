from fastapi import APIRouter, Depends
from fastapi.exceptions import HTTPException
from http import HTTPStatus
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from schemas import SoftwareSchema, SoftwareDB
from models import SoftwareModel
from database import get_session

router = APIRouter(prefix='/softwares', tags=['softwares'])

@router.get('/', status_code=HTTPStatus.OK, response_model=list[SoftwareDB])
def get_softwares(session: Session = Depends(get_session)):
    db_softwares = session.scalars(select(SoftwareModel)).all()
    return db_softwares

@router.get('/{id}', status_code=HTTPStatus.OK, response_model=SoftwareDB)
def get_software(id: int, session: Session = Depends(get_session)):
    db_software = session.scalar(
        select(SoftwareModel).where(SoftwareModel.id == id)
    )
    if not db_software:
        raise HTTPException(status_code=HTTPStatus.NOT_FOUND, detail="Software não encontrado")
    
    return db_software

@router.post('/', status_code=HTTPStatus.CREATED, response_model=SoftwareDB)
def create_software(software: SoftwareSchema, session: Session = Depends(get_session)):
    # O model_dump() agora vai pegar os nomes 'nome', 'versao_esperada', etc.
    db_software = SoftwareModel(**software.model_dump())

    try:
        session.add(db_software)
        session.commit()
        session.refresh(db_software)
    except IntegrityError:
        session.rollback()
        raise HTTPException(
            status_code=HTTPStatus.CONFLICT,
            detail="Este software já está cadastrado!"
        )
    return db_software

@router.put('/{id}', status_code=HTTPStatus.OK, response_model=SoftwareDB)
def put_software(id: int, software: SoftwareSchema, session: Session = Depends(get_session)):
    db_software = session.scalar(
        select(SoftwareModel).where(SoftwareModel.id == id)
    )

    if not db_software:
        raise HTTPException(status_code=HTTPStatus.NOT_FOUND, detail="Software não encontrado")
    
    # ATUALIZADO: Usando os novos nomes de campos que batem com seu script
    db_software.nome = software.nome
    db_software.versao_esperada = software.versao_esperada 
    db_software.caminho_padrao = software.caminho_padrao

    session.commit()
    session.refresh(db_software)
    return db_software

@router.delete('/{id}', status_code=HTTPStatus.OK, response_model=SoftwareDB)
def delete_software(id: int, session: Session = Depends(get_session)):
    db_software = session.scalar(
        select(SoftwareModel).where(SoftwareModel.id == id)
    )

    if not db_software:
        raise HTTPException(status_code=HTTPStatus.NOT_FOUND, detail="Software não encontrado")
    
    session.delete(db_software)
    session.commit()
    return db_software