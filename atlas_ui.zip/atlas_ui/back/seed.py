from database import SessionLocal
from models import SoftwareModel
import os

def popular_dados():
    db = SessionLocal()
    try:
        # Note que agora usamos 'nome' em vez de 'nome_software'
        softwares_corporativos = [
            SoftwareModel(
                nome="Google Chrome", 
                versao_esperada="120.0", 
                caminho_padrao=r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"
            ),
            SoftwareModel(
                nome="Visual Studio Code", 
                versao_esperada="1.85", 
                caminho_padrao=r"%LocalAppData%\Programs\Microsoft VS Code\Code.exe"
            ),
            SoftwareModel(
                nome="Git", 
                versao_esperada="2.43", 
                caminho_padrao=r"%ProgramFiles%\Git\bin\git.exe"
            ),
            SoftwareModel(
                nome="Microsoft Edge", 
                versao_esperada="119.0", 
                caminho_padrao=r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
            ),
            SoftwareModel(
                nome="Python 3.11", 
                versao_esperada="3.11", 
                caminho_padrao="N/A" # Se o seu campo no banco não aceitar None, coloque "N/A"
            )
        ]

        print(f"🌱 Inserindo {len(softwares_corporativos)} softwares no banco...")

        for s in softwares_corporativos:
            db.add(s)
        
        db.commit()
        print("✅ Base de dados populada com sucesso!")

    except Exception as e:
        print(f"❌ Erro ao popular: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    popular_dados()