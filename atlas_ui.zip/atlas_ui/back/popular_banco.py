import requests
import time

URL = "http://127.0.0.1:8000/softwares/"

# LISTA CORRIGIDA COM AS CHAVES QUE O SEU BACKEND EXIGE
softwares_para_inserir = [
    {"nome": "Google Chrome", "versao_esperada": "122.0", "caminho_padrao": r"C:\Program Files\Google\Chrome\Application\chrome.exe"},
    {"nome": "Python", "versao_esperada": "3.11.0", "caminho_padrao": r"C:\Windows\py.exe"},
    {"nome": "VS Code", "versao_esperada": "1.85.0", "caminho_padrao": r"%LocalAppData%\Programs\Microsoft VS Code\Code.exe"},
    {"nome": "Git", "versao_esperada": "2.43.0", "caminho_padrao": r"C:\Program Files\Git\bin\git.exe"},
    {"nome": "Microsoft Edge", "versao_esperada": "122.0", "caminho_padrao": r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"},
    {"nome": "Notepad++", "versao_esperada": "8.6.0", "caminho_padrao": r"C:\Program Files\Notepad++\notepad++.exe"},
    {"nome": "VLC Media Player", "versao_esperada": "3.0.0", "caminho_padrao": r"C:\Program Files\VideoLAN\VLC\vlc.exe"},
    {"nome": "WinRAR", "versao_esperada": "6.0", "caminho_padrao": r"C:\Program Files\WinRAR\WinRAR.exe"},
    {"nome": "7-Zip", "versao_esperada": "23.0", "caminho_padrao": r"C:\Program Files\7-Zip\7zFM.exe"},
    {"nome": "Spotify", "versao_esperada": "1.0", "caminho_padrao": r"%AppData%\Spotify\Spotify.exe"},
    {"nome": "Discord", "versao_esperada": "1.0", "caminho_padrao": r"%LocalAppData%\Discord\Update.exe"},
    {"nome": "Slack", "versao_esperada": "4.0", "caminho_padrao": r"C:\Program Files\Slack\slack.exe"},
    {"nome": "Docker Desktop", "versao_esperada": "4.0", "caminho_padrao": r"C:\Program Files\Docker\Docker\Docker Desktop.exe"},
    {"nome": "AnyDesk", "versao_esperada": "7.0", "caminho_padrao": r"C:\Program Files (x86)\AnyDesk\AnyDesk.exe"},
    {"nome": "TeamViewer", "versao_esperada": "15.0", "caminho_padrao": r"C:\Program Files\TeamViewer\TeamViewer.exe"},
    {"nome": "Zoom", "versao_esperada": "5.0", "caminho_padrao": r"%AppData%\Zoom\bin\Zoom.exe"},
    {"nome": "Steam", "versao_esperada": "1.0", "caminho_padrao": r"C:\Program Files (x86)\Steam\steam.exe"},
    {"nome": "Postman", "versao_esperada": "10.0", "caminho_padrao": r"%LocalAppData%\Postman\Postman.exe"},
    {"nome": "DBeaver", "versao_esperada": "23.0", "caminho_padrao": r"C:\Program Files\DBeaver\dbeaver.exe"},
    {"nome": "Java JRE", "versao_esperada": "1.8", "caminho_padrao": r"C:\Program Files\Java\jre1.8.0_202\bin\java.exe"},
    {"nome": "Adobe Reader", "versao_esperada": "2024.0", "caminho_padrao": r"C:\Program Files\Adobe\Acrobat DC\Acrobat\Acrobat.exe"},
    {"nome": "Node.js", "versao_esperada": "20.0", "caminho_padrao": r"C:\Program Files\nodejs\node.exe"},
    {"nome": "Obsidian", "versao_esperada": "1.5", "caminho_padrao": r"%LocalAppData%\Obsidian\Obsidian.exe"},
    {"nome": "PuTTY", "versao_esperada": "0.80", "caminho_padrao": r"C:\Program Files\PuTTY\putty.exe"},
    {"nome": "PowerBI Desktop", "versao_esperada": "2.0", "caminho_padrao": r"C:\Program Files\Microsoft Power BI Desktop\bin\PBIDesktop.exe"}
]

def executar():
    inicio = time.time()
    print(f"🚀 Enviando {len(softwares_para_inserir)} softwares para o banco...")
    
    sucessos = 0
    for sw in softwares_para_inserir:
        try:
            # Forçamos o requests a NÃO usar proxy para esta chamada
            response = requests.post(URL, json=sw, proxies={"http": None, "https": None})
            
            if response.status_code in [200, 201]:
                print(f"✅ Adicionado: {sw['nome']}")
                sucessos += 1
            else:
                print(f"⚠️ Erro no {sw['nome']}: {response.status_code}")
            
            # Pequena pausa para evitar o "Flood" no Proxy da empresa
            time.sleep(0.1) 
            
        except Exception as e:
            print(f"❌ Falha crítica: {e}")

    fim = time.time()
    print(f"\n✅ {sucessos} softwares inseridos com sucesso em {fim-inicio:.2f}s!")

if __name__ == "__main__":
    executar()