from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from jwt import encode

from pwdlib import PasswordHash

pwd_context = PasswordHash.recommended()


SECRETY_KEY= 'my-secret-key'
ALGORITHM= 'HS256'
ACCESS_TOKEN_EXPIRE_MINUTES=30


def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(token_data: dict) -> str:
    to_encode = token_data.copy()

    expire =  datetime.now(ZoneInfo('UTC')) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode.update({'exp' : expire })

    encoded_jwt = encode(to_encode, key=SECRETY_KEY, algorithm=ALGORITHM)


    return encoded_jwt
    