from database import engine, Base
import models # Força o SQLAlchemy a carregar a classe Software

print("🛠️ Criando tabelas no PostgreSQL...")
Base.metadata.create_all(bind=engine)
print("✅ Tabelas criadas com sucesso!")