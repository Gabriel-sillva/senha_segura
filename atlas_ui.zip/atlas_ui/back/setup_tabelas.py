from database import engine
try:
    # Tenta importar o Base do database.py
    from database import Base
except ImportError:
    # Se não estiver lá, tenta importar do models.py (onde as tabelas são definidas)
    from models import Base

import models  # Garante que o SQLAlchemy carregue as classes das tabelas

def criar_estrutura():
    print("🛠️  Conectando ao PostgreSQL e mapeando modelos...")
    try:
        # Esse comando lê o Base e cria as tabelas no banco conectado à 'engine'
        Base.metadata.create_all(bind=engine)
        print("✅ Tabelas criadas ou atualizadas com sucesso no banco 'atlas'!")
    except Exception as e:
        print(f"❌ Erro ao criar tabelas: {e}")
        print("\nVerifique se a URL no database.py está assim:")
        print("postgresql://postgres:root@localhost:5432/atlas")

if __name__ == "__main__":
    criar_estrutura()