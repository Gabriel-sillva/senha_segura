from datetime import datetime
from sqlalchemy import func
from sqlalchemy.orm import Mapped, mapped_column, registry

table_registry = registry()

@table_registry.mapped_as_dataclass
class SoftwareModel:
    __tablename__ = 'softwares'

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True, init=False)
    nome: Mapped[str] = mapped_column(unique=True) 
    versao_esperada: Mapped[str]
    caminho_padrao: Mapped[str]

    created_at: Mapped[datetime] = mapped_column(server_default=func.now(), init=False)


    
@table_registry.mapped_as_dataclass
class LogVarreduraModel:
    __tablename__ = 'logs_varredura'

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True, init=False)
    hostname: Mapped[str]
    nome_software: Mapped[str]
    versao_instalada: Mapped[str]
    versao_esperada: Mapped[str]
    status: Mapped[str]
    data_verificacao: Mapped[str]
    created_at: Mapped[datetime] = mapped_column(server_default=func.now(), init=False)