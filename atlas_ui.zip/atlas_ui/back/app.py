from fastapi import FastAPI, Depends
from fastapi.exceptions import HTTPException
from http import HTTPStatus
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from models import table_registry
from database import engine

# --- IMPORTAÇÃO DE SCHEMAS ---
from schemas import (
    SoftwareSchema, SoftwareDB, # UserSchema,  <-- Comentei referências a User
    # UserPublicSchema, Token, 
    LogVarreduraSchema
)

# --- IMPORTAÇÃO DE MODELS ---
from models import SoftwareModel, LogVarreduraModel # Removido UserModel daqui

from database import get_session
# from security import hash_password, verify_password, create_access_token <-- Comentei pois auth foi removido
from routes import softwares # Removido 'auth' daqui

# Inicializa o FastAPI
app = FastAPI(title="TCC Backend API")

# --- REGISTRO DE ROTAS (ROUTERS) ---
# app.include_router(auth.router) <-- COMENTADO: Isso evitara o erro no routes/auth.py
app.include_router(softwares.router)

# Isso cria as tabelas automaticamente no arquivo .db assim que a API liga
table_registry.metadata.create_all(bind=engine)

# --- NOVA ROTA: RECEBER LOGS DA VARREDURA ---
@app.post("/logs/", status_code=HTTPStatus.CREATED)
def criar_log_varredura(log: LogVarreduraSchema, session: Session = Depends(get_session)):
    novo_log = LogVarreduraModel(
        hostname=log.hostname,
        nome_software=log.nome_software,
        versao_instalada=log.versao_instalada,
        versao_esperada=log.versao_esperada,
        status=log.status,
        data_verificacao=log.data_verificacao
    )
    
    session.add(novo_log)
    session.commit()
    session.refresh(novo_log)
    
    return {"message": "Log registrado com sucesso!", "id": novo_log.id}

# --- ROTA PARA CONSULTAR OS LOGS ---
@app.get("/logs/", response_model=list[LogVarreduraSchema])
def listar_logs(session: Session = Depends(get_session)):
    return session.scalars(select(LogVarreduraModel)).all()

if __name__ == "__main__":
    import uvicorn
    # Usar "localhost" em vez de "127.0.0.1" no host ajuda a evitar o proxy
    uvicorn.run(app, host="localhost", port=8000)