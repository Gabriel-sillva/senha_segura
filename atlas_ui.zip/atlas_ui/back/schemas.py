from pydantic import BaseModel

# --- SCHEMAS DE SOFTWARE ---
class SoftwareSchema(BaseModel):
    nome: str
    versao_esperada: str
    caminho_padrao: str

class SoftwareDB(SoftwareSchema):
    id: int
    
    class Config:
        from_attributes = True

# --- SCHEMAS DE USUÁRIO ---
class UserSchema(BaseModel):
    username: str
    email: str
    password: str

class UserPublicSchema(BaseModel):
    username: str
    email: str

# --- SCHEMA DE AUTENTICAÇÃO ---
class Token(BaseModel):
    access_token: str
    token_type: str

# --- NOVO SCHEMA PARA O CONTRATO DE DADOS (LOGS DE VARREDURA) ---
# Este é o JSON que o seu executável vai enviar para a API
class LogVarreduraSchema(BaseModel):
    hostname: str
    nome_software: str
    versao_instalada: str
    versao_esperada: str
    status: str
    data_verificacao: str

    class Config:
        from_attributes = True